#include "LineSensors.h"
#include <Zumo32U4.h>

// Maak een object aan voor de Zumo32U4ButtonA en Zumo32U4LineSensors
Zumo32U4ButtonA buttonA;
Zumo32U4LineSensors lineSensors;
Zumo32U4Motors motors;

// initialiseer 3 sensoren
LineSensors::LineSensors() : LaatsteGelezenUitvoer(0){
    for (int i = 0; i < 5; ++i) {
        lineSensorValues[i] = 0;
    }
}

// void LineSensors::initSensors() {
//     lineSensors.initFiveSensors();
//     Serial.println("Druk op knop A om te kalibreren...");
//     while (!buttonA.isPressed()) {
//         delay(100);
//     }

//     calibrateLineSensor();
//     updateThresholds();
//     Serial.println("Kalibratie voltooid.");
// }

void LineSensors::updateThresholds() {
    int minValues[5] = {1000, 1000, 1000, 1000, 1000};
    int maxValues[5] = {0, 0, 0, 0, 0};
    for (int i = 0; i < 40; i++) {
        lineSensors.readCalibrated(lineSensorValues);
        for (int j = 0; j < 5; j++) {
            if (lineSensorValues[j] < minValues[j]) {
                minValues[j] = lineSensorValues[j];
            }
            if (lineSensorValues[j] > maxValues[j]) {
                maxValues[j] = lineSensorValues[j];
            }
        }
        delay(20);
    }
    blackThreshold = (minValues[0] + minValues[1] + minValues[2] + minValues[3] + minValues[4]) / 5 + 50;
    whiteThreshold = (maxValues[0] + maxValues[1] + maxValues[2] + maxValues[3] + maxValues[4]) / 5 - 50;
    greenThreshold = (blackThreshold + whiteThreshold) / 2;

    Serial.print("Zwart: "); Serial.println(blackThreshold);
    Serial.print("Wit: "); Serial.println(whiteThreshold);
    Serial.print("Groen: "); Serial.println(greenThreshold);
}

int LineSensors::startup() {
    if (status == 0){
        if (buttonA.getSingleDebouncedPress()){
            // Serial.println("Knop A is ingedrukt!");
            delay(1000);
            // Serial.println("Feck1");
            lineSensors.initFiveSensors();
            pinMode(5, OUTPUT); // Zet groene led op pin 5 op output
            // Serial.println("Feck2");
            calibrateLineSensor();
            // Serial.println("Feck3");
            Serial.begin(9600);
            status=1;
            Serial.println(status);
            return status;
        }
    }
}

int LineSensors::checkWaardesLS() {
    if ((uint16_t)(millis() - LaatsteGelezenUitvoer) >= 100) {
        LaatsteGelezenUitvoer = millis();
        lineSensors.readCalibrated(lineSensorValues);
        printReadingsToSerial(); 
        return 0;
    }
}

int LineSensors::calibrateLineSensor() {
    Serial.println("Kalibreren...");
    for (int j = 0; j < 3; j++) {
        for (int i = 0; i < 50; i++) {
            lineSensors.calibrate();
            motors.setLeftSpeed(200);
            motors.setRightSpeed(-200);
            delay(10);
        }
    }
    motors.setLeftSpeed(0);
    motors.setRightSpeed(0);
    return 0;
}

void LineSensors::printReadingsToSerial() {
    // Serial.print("Line sensoren output: ");
    for (uint8_t i = 0; i < 5; i++) {
        int mappedValue = map(lineSensorValues[i], 0, 1000, 0, 10000);
        // Serial.print(mappedValue);
        // Serial.print(" ");
    }
    // Serial.println(); 
}

int LineSensors::checkLijnen(bool &allWhite) {
    int16_t position = lineSensors.readLine(lineSensorValues);
     allWhite = true;
      for (uint8_t i = 0; i < 5; i++) {
        if (lineSensorValues[i] < 900) {  // Adjust threshold as needed
            allWhite = false;
            break;
        }
    Serial.print("Dit is van de Readline ");
    Serial.print(position);
    Serial.print(" .\n");
    // delay (1000);
    // for (uint8_t i = 0; i < 5; i++) {
    //     if (lineSensorValues[i] > 550) {
    //         allWhite = 0;
    //         break;
    //     }
    // }
    // if (allWhite == 1) {
    //     Serial.println("Lijn verloren!");
    //     return -1;
    // }
    return position;
  }
}
int LineSensors::KleurCheck() {
    for (int i = 0; i < 5; ++i) {
        if (i == 0) {
            LSKleur = lineSensorValues[i];
        }
        if (i == 1) {
            LSKleur1 = lineSensorValues[i];
        }
        if (i == 2) {
            LSKleur2 = lineSensorValues[i];
        }
        if (i == 3) {
            LSKleur3 = lineSensorValues[i];
        }
        if (i == 4) {
            LSKleur4 = lineSensorValues[i];
        }
    }
}

String LineSensors::LSrouteVersturen() {
  String kleur;
    if (LSKleur > 1500 && LSKleur < 2000 || LSKleur4 > 1700 && LSKleur4 < 2200 ) {
        Serial.print("GrijsL+R Waar! ");
        kleur = "GrijsLR";
        return kleur;
    }
    else if (LSKleur > 1500 && LSKleur < 2000) {
        Serial.print("GrijsL Waar! ");
        kleur = "GrijsL";
        return kleur;
    }
    else if (LSKleur4 > 1700 && LSKleur4 < 2200) {
        Serial.print("GrijsR Waar! ");
        kleur = "GrijsR";
        return kleur;
    }
   else  if (LSKleur3 > 600 && LSKleur3 < 1500) {
        Serial.print("Groen Waar! ");
        kleur = "Groen";
        return kleur;
    }
    else if (LSKleur > 2500 && LSKleur < 3000) {
        Serial.print("BruinL Waar! ");
        kleur = "BruinL";
        return kleur;
    }
    else if (LSKleur4 > 2700 && LSKleur4 < 3500) {
        Serial.print("BruinR Waar! ");
        kleur = "BruinR";
        return kleur;
    }
    else {
      kleur = "Zwart";
    }
    return kleur;
}

int LineSensors::SensorenE() {
    int tijdelijk = 0 ;
    for (int i = 0; i < 5; ++i) {
        tijdelijk += lineSensorValues[i];
    }
    if (tijdelijk == 0) {
        return 1;
    }
    return 0;
}

// bool LineSensors::detectColor(int sensorIndex, unsigned int thresholdLow, unsigned int thresholdHigh) {
//     return (lineSensorValues[sensorIndex] > thresholdLow && lineSensorValues[sensorIndex] < thresholdHigh);
// }

// int LineSensors::readLineSensors() {
//     return lineSensors.readLine(lineSensorValues);
// }
