#include "Motors.h"
#include "LineSensors.h"
#include <Zumo32U4.h>
#include <Wire.h>

// PID parameters
#define KP 0.8
#define KD 1.2
#define KI 0.0

#define turnDelay 1050
#define defaultDelay 1000

Motors::Motors()
: speedLeft(0), speedRight(0), userSpeed(0), lastError(0), integral(0), command(0), errorLeft(false), errorRight(false), countsLeft(0), countsRight(0) {}

int Motors::lineFollow(int maxSpeed, int lineValues, bool allWhite, String kleur) {
    int position = lineValues;
    error = position - 2000;  // Dit zou afhankelijk moeten zijn van de breedte van de lijnsensoren
    integral += error;
    int derivative = error - lastError;
    int motorSpeed = KP * error + KD * derivative + KI * integral;
    if (allWhite) {
        straight();
    } 
    lastError = error;
    int leftSpeed = maxSpeed + motorSpeed;
    int rightSpeed = maxSpeed - motorSpeed;
    // Serial.print("MaxSpeed: ");
    // Serial.print(maxspeed );
    leftSpeed = constrain(leftSpeed, -400, 400);
    rightSpeed = constrain(rightSpeed, -400, 400);
    // if (kleur == "Groen"){
    //   leftSpeed = leftSpeed / 2;
    //   rightSpeed = rightSpeed / 2;
    // }
    // Serial.print("leftspeed: ");
    // Serial.print(leftSpeed );
    // Serial.print("righspeed: ");
    // Serial.print(rightSpeed );
    motors.setLeftSpeed(leftSpeed);
    motors.setRightSpeed(rightSpeed);
    delay(20);
    // Serial.print("error: ");
    // Serial.print(error);
    
    return 0;
  }
int Motors::speedBlack() {
    return 400;
}

int Motors::speedGreen() {
    return 200;
}

void Motors::printSpeed() {
    Serial.print("Left speed: ");
    Serial.print(speedLeft);
    Serial.print("\tRight speed: ");
    Serial.println(speedRight);
}

void Motors::handleUserCommands() {
    if (Serial.available() > 0) {
        char command = Serial.read();
        switch (command) {
            case 'F':
                straight();
                break;
            case 'B':
                stop();
                break;
            case 'L':
                turnLeft();
                break;
            case 'R':
                turnRight();
                break;
            case 'S':
                stop();
                break;
        }
    }
}

void Motors::turnRight() {
    motors.setLeftSpeed(200);
    motors.setRightSpeed(-200);
    delay(turnDelay);
    stop();
}

void Motors::turnLeft() {
    motors.setLeftSpeed(-200);
    motors.setRightSpeed(200);
    delay(turnDelay);
    stop();
}

void Motors::straight() {
    motors.setLeftSpeed(200);
    motors.setRightSpeed(200);
}

void Motors::stop() {
    motors.setLeftSpeed(0);
    motors.setRightSpeed(0);
}

void Motors::circleClockwise() {
    motors.setLeftSpeed(200);
    motors.setRightSpeed(-200);
}

void Motors::circleCounterClockwise() {
    motors.setLeftSpeed(-200);
    motors.setRightSpeed(200);
}
